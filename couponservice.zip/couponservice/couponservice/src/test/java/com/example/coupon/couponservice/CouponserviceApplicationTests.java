package com.example.coupon.couponservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
