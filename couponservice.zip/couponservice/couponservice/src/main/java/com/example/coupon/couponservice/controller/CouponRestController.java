package com.example.coupon.couponservice.controller;

import com.example.coupon.couponservice.coupon.Coupon;
import com.example.coupon.couponservice.repository.CouponRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/couponapi")
public class CouponRestController{

    @Autowired
    CouponRepo couponRepo;

    @RequestMapping(value = "/coupon" , method = RequestMethod.POST)
    public Coupon createCoupon(@RequestBody Coupon coupon){
        return couponRepo.save(coupon);
    }

    @RequestMapping(value = "/coupon/{code}" , method = RequestMethod.GET)
    public Coupon getCouponCode(@PathVariable("code") String code){
        return couponRepo.findByCode(code);
    }

}
