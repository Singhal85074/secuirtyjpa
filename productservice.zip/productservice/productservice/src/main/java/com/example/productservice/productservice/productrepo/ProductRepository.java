package com.example.productservice.productservice.productrepo;

import com.example.productservice.productservice.modal.ProductService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<ProductService , Long> {
}
